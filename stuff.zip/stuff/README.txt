Dear CS3600 student.

Be very careful what you copy from this folder.
Patrick Taylor wants to find reasons to change your course grade to zero, as he did to many students after finals week was over.

The following was posted by an anonymous student on RateMyProfessor.com on 12/19/2017 regarding CS3600:
"""Dr. Taylor is a nice guy and knows his stuff, but students should be warned of his behavior. After finals week, he CHANGED existing grades to 0's, accusing students of cheating due to having similar pieces of code and for using online resources for quizzes. He prevented people that didn't cheat from graduating. He purposely waited for max damage."""

Why is it that Patrick Taylor always gets what he wants?
Patrick Taylor changed grades to zero after finals week was over, while Dr. Markowski was forced to curve grades up.
Patrick Taylor installed his security class as required, and is now installing another one of his own classes (CS1500) as required.
As of me writing this (May 2019), CS1500 is not anywhere online.
But they wouldn't let my younger brother enroll in CS1570 because they are requiring him to get CS1500 credit first.



I tried to take CS3600 in the fall of 2018.
I will never take a Patrick Taylor class again.
When the grades for pa01 came out, more than half the class got a 0, including myself.
Patrick Taylor announced that it was the students fault, and accused them of not running the command they were provided to test their code.
I had very much run the provided command, in multiple environments, with multiple versions of python.
I went to the grader's office hours, and the grader showed me a long list of errors.
The error he got from my program was like IOError: failed to open file "Dictionary.txt".
Two days later, my grade was changed to 100.
I had never dealt with such low quality grading before.

The day before pa03 was due, I had worked on it for approximately 30 hours (it was due over between 1 and 2 weeks).
But there was no hope for me to complete the assignment.
So I dropped the class.
The day I dropped, I was added to a GroupMe.
All the answers were posted there.
Patrick Taylor had provided a Canvas forum, but the students wisely didn't use it, since Patrick Taylor saw everything there.

When I took this class, the were no redos on any assignments except pa01, but I believe this has changed in more recent semesters (I hope so).

pa01 was assigned Thursday of week 2 and due Tuesday of week 3.
pa02 was assigned about the time pa01 was due.
pa03 was assigned about the time pa02 was due.
But then no assignments were posted for 4 weeks.
Then another sequence of assignments began.
The final was posted late (Taylor said it would be posted before the last class day, and it wasn't).

I dropped the class the day before pa03 was due, but I tried to do the rest of the assignments anyway.
Some of them I was able to do, and others I was not.
Since no assignments were dropped, I probably would not have passed this class if I had submitted was is in this folder. 

When you take this class, prepare for unimaginable workloads, but only half the time.
When assignments are available, you will not have time for anything else.
FIGHT to get into the GroupMe.
You cannot pass the class without the GroupMe.
Do not listen to the lectures, since they present more lies than truth.
