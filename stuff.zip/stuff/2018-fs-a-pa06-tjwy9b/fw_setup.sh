#!/usr/bin/env bash

# This shell script is executed automatically on startup.
readonly PRE_UP_FILE=/etc/network/if-pre-up.d/iptables

# This file will contain the rules.
readonly RULES_FILE=/etc/network/if-pre-up.d/rules.rules

# Specify the interpreter at the top of the file.
echo "#!/bin/sh" > $PRE_UP_FILE

# Execute the iptables-restore command with the saved rules.
echo "/sbin/iptables-restore < " $RULES_FILE >> $PRE_UP_FILE

# Make the startup script executable.
chmod +x $PRE_UP_FILE

# Write the rules file.
cat rules.rules > $RULES_FILE

# Execute the startup script to apply the rules to the current session.
bash $PRE_UP_FILE


