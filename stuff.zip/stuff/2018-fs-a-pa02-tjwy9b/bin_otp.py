#!/usr/bin/env python
# Programmer: Tanner Winkelman
# Instructor: Patrick Taylor
# Class: cs3600
# Assignment: pa02

import sys


def get_key(keyfile, keynum):
    """
    Retrieves a key from the keyfile by number.
    :param keyfile: Whatever the open() function returns.
    :param keynum: The number of the key.  Must appear at the beginning of the line, separated from the key by a space.
    :return: The key string, as it appears in the file.
    """
    key = ''
    for line in keyfile:
        x = 0
        while x < len(line) and line[x] in '0123456789':
            x += 1
        line_key_num = int(line[0:x])
        if keynum == line_key_num:
            key = line.split()[1]
    return key


def get_ba_from_key(key):
    """
    Converts strings of 1 and 0 to bytearrays.
    :param key: Key should be a string consisting of '1' and '0' chars.  That's right, the chars for the digits 1 and 0.
    :return: A bytearray with the bits indicated by the input string.
    """
    byte = 0x00
    count = 0
    ba_key = bytearray()
    for bit in key:
        if bit == '1':
            byte |= 0x01
        count += 1
        if count >= 8:
            ba_key.append(byte)
            byte = 0x00
            count = 0
        else:
            byte = byte << 1
    return ba_key


def main():
    """
    The main function.
    """
    keyfilename = sys.argv[1]
    keynum = int(sys.argv[2])
    input_file_name = sys.argv[3]
    output_file_name = sys.argv[4]
    with \
            open(keyfilename, 'r') as keyfile, \
            open(input_file_name, 'rb') as input_file, \
            open(output_file_name, 'wb') as output_file:
        key = get_key(keyfile, keynum)
        ba_key = get_ba_from_key(key)
        ba_input = bytearray(input_file.read())
        ba_translated = bytearray(ba_key[i % len(ba_key)] ^ ba_input[i] for i in range(len(ba_input)))
        output_file.write(ba_translated)




if __name__ == '__main__':
    main()
