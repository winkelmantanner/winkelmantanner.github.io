#!/usr/bin/env python
# Programmer: Tanner Winkelman
# Instructor: Patrick Taylor
# Class: cs3600
# Assignment: pa02

from sys import argv
import os

NUM_BITS_IN_BYTE = 8
NUM_KEYS = 500
KEY_NUM_OUTPUT_WIDTH = 3
NUM_BITS_IN_KEY = 2048


def generate_binary_string(length):
    for k in range(int(length / NUM_BITS_IN_BYTE)):
        shifted = ord(os.urandom(1))
        for j in range(NUM_BITS_IN_BYTE):
            if shifted & 1 == 0:
                yield '0'
            else:
                yield '1'
            shifted = shifted >> 1

def main():
    output_filename = argv[1]
    with open(output_filename, 'w') as output_file:
        for k in range(NUM_KEYS):
            randomString = ''.join(generate_binary_string(NUM_BITS_IN_KEY))

            output_file.write(str(k + 1).zfill(KEY_NUM_OUTPUT_WIDTH) + ' ' + randomString + '\r\n')


if __name__=='__main__':
    main()
