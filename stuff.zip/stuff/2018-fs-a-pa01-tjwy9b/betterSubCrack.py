#!/usr/bin/env python3
# Programmer: Tanner Winkelman
# Instructor: Patrick Taylor
# Class: cs3600
# Assignment: pa01


from sys import argv

from simpleSubCipher import LETTERS

LETTERS_DICT = {letter: None for letter in LETTERS}

DICTIONARY_FILENAME = 'dictionary.txt'


MIN_WORD_LENGTH = 2

# we only count the word patterns that have at most this many words in the dictionary with the pattern
MAX_NUM_WORDS_TO_COUNT = 50
MIN_SIGNIFICANCE_TO_COUNT = float(1) / MAX_NUM_WORDS_TO_COUNT

CRITICAL_SIGNIFICANCE = 15


def get_word_pattern(word):
    """
    Gets the word pattern of a string.
    :param word: May contain spaces and dots.  The string to find the pattern of.
    :return: The word pattern (e.g. '012234' for 'TANNER')
    """
    charToNumberMap = {}
    pattern = []
    currentNumber = 0
    for char in word:
        if char in charToNumberMap:
            pattern.append(charToNumberMap[char])
        elif char in LETTERS_DICT:
            charToNumberMap[char] = currentNumber
            currentNumber += 1
            pattern.append(charToNumberMap[char])
    return ''.join(map(str,pattern))


def getWordPatternsFromDictionary(dictionaryWordIterable):
    wordPatterns = {}
    for line in dictionaryWordIterable:
        if len(line) >= MIN_WORD_LENGTH:
            pattern = get_word_pattern(line)
            if pattern in wordPatterns:
                wordPatterns[pattern].append(line)
            else:
                wordPatterns[pattern] = [line]
    return wordPatterns


def getLetterFrequencies(text):
    """
    Get the letter frequencies of text.
    :param text: The text to get the letter frequencies of.
    :return: A tuple whose entries correspond to those in LETTERS.
    """
    letterCounts = {char:0 for char in LETTERS}
    for char in text:
        if char in letterCounts:
            letterCounts[char] += 1
    return tuple(letterCounts[char] for char in LETTERS)


def max_index(listOfNumbers):
    """
    Find the index of the greatest number in a list of numbers.
    :param listOfNumbers: A list of numbers.
    :return: The index of the max number in the list of numbers.  -1 for list with no positive numbers.
    """
    maxIndex = -1
    max = 0
    for index, number in enumerate(listOfNumbers):
        if number > max:
            max = number
            maxIndex = index
    return maxIndex


def countChar(fromChar, toChar, fromDict, significance ):
    """
    Used to find probabilities of character mappings based on word patterns.
    :param fromChar: The outer key.
    :param toChar: The inner key.
    :param fromDict: The 2-d dictionary, which may be empty or lack either key.
    :param significance: The weight of the mapping.
    :return: Does NOT return
    """
    if fromChar in fromDict:
        if toChar in fromDict[fromChar]:
            fromDict[fromChar][toChar] += significance
        else:
            fromDict[fromChar][toChar] = significance
    else:
        fromDict[fromChar] = {toChar: significance}


def processWord(word, mappingCountsFromEachEncryptedChar, mappingCountsToEachDecryptedChar, wordPatterns):
    """

    :param word:
    :param mappingCountsFromEachEncryptedChar:
    :param mappingCountsToEachDecryptedChar:
    :param wordPatterns:
    :return:
    """
    wordPattern = get_word_pattern(word)
    if wordPattern in wordPatterns:
        possibleWords = wordPatterns[wordPattern]
        significance = float(1)/len(possibleWords)
        if significance > MIN_SIGNIFICANCE_TO_COUNT:
            for wordFromDictionary in possibleWords:
                for index, char in enumerate(wordFromDictionary):
                    countChar(char, word[index], mappingCountsFromEachEncryptedChar, significance)
                    countChar(word[index], char, mappingCountsToEachDecryptedChar, significance)



def processWord2(word, mappingCountsFromEachEncryptedChar, mappingCountsToEachDecryptedChar, wordPatterns, solvedChars):
    """
    The future of processWord.
    :param word:
    :param mappingCountsFromEachEncryptedChar:
    :param mappingCountsToEachDecryptedChar:
    :param wordPatterns:
    :param solvedChars:
    :return:
    """
    wordPattern = get_word_pattern(word)
    if wordPattern in wordPatterns:
        significance = float(1)/len(wordPatterns[wordPattern])
        if significance > MIN_SIGNIFICANCE_TO_COUNT:
            wordsWithPattern = wordPatterns[wordPattern]
            possibleWords = []
            for wordFromDictionary in wordsWithPattern:
                isThisWordPossiblyTheOne = True
                for index, char in enumerate(wordFromDictionary):
                    if word[index] in solvedChars:
                        if solvedChars[word[index]] != char:
                            isThisWordPossiblyTheOne = False
                            break
                if isThisWordPossiblyTheOne:
                    possibleWords.append(wordFromDictionary)

            if len(possibleWords) > 0:

                # update significance to match new number of possible words
                significance = float(1)/len(possibleWords)

                for wordFromDictionary in possibleWords:
                    for index, char in enumerate(wordFromDictionary):
                        countChar(char, word[index], mappingCountsFromEachEncryptedChar, significance)
                        countChar(word[index], char, mappingCountsToEachDecryptedChar, significance)
                        if mappingCountsToEachDecryptedChar[word[index]][char] > CRITICAL_SIGNIFICANCE:
                            solvedChars[word[index]] = char


def dictSum(dict):
    sum = 0
    for key in dict:
        sum += dict[key]
    return sum

def dictMaxKey(dict):
    maxVal = 0
    maxKey = '0'
    for key in dict:
        if dict[key] > maxVal:
            maxVal = dict[key]
            maxKey = key
    return maxKey


def decryptChar(char, solvedChars):
    if not char.upper() in LETTERS_DICT:
        # handle unencrypted chars
        return char
    else:
        # handle upper and lower case encrypted chars
        if char in LETTERS_DICT and char not in ' .':
            return solvedChars[char]
        else:
            return solvedChars[char.upper()].lower()


def find_dot(words):
    endCounts = {char.upper():1 for char in LETTERS}
    nonEndCounts = {char.upper():1 for char in LETTERS}
    for word in words:
        if word != '':
            for char in word.upper()[0:-1]:
                if char in nonEndCounts:
                    nonEndCounts[char] += 1
                else:
                    nonEndCounts[char] = 1
            lastChar = word[-1].upper()
            if lastChar in endCounts:
                endCounts[lastChar] += len(word)
            else:
                endCounts[lastChar] = len(word)
    return dictMaxKey({char:(float(endCounts[char])/nonEndCounts[char]) for char in endCounts if char in nonEndCounts})

def generateSpaceText(text, spaceChar):
    onWhitespace = False
    for char in text:
        if char in LETTERS:
            yield char
            onWhitespace = False
        elif char in '\r\n\t':
            onWhitespace = True
            yield spaceChar

def checkCorrectness(text1, text2):
    wrongCount = 0
    for index in range(len(text1)):
        if text1[index] != text2[index]:
            wrongCount += 1
    return 1 - (float(wrongCount) / len(text1))


def spaceCharForWhiteSpace(text, spaceChar):
    return ''.join(generateSpaceText(text, spaceChar))

def flipKey(key):
    return ''.join(key[LETTERS.find(key[index])] for index in range(len(key)))

def decryptSpacesAndDots(inputText):
    solvedChars = {}

    # get all caps text with only chars that are in the given set of letters
    cleanedEncrypted = ''.join(c for c in inputText.upper() if c in LETTERS_DICT)

    letterFrequencies = getLetterFrequencies(cleanedEncrypted)

    # space is the most common char by far, so go ahead and solve it
    spaceChar = LETTERS[max_index(letterFrequencies)]
    solvedChars[spaceChar] = ' '

    # get all caps text with only chars that are in the given set of letters
    cleanedEncrypted = ''.join(spaceCharForWhiteSpace(inputText.upper(), spaceChar))
    wordPatterns = {}
    with open(DICTIONARY_FILENAME, 'r') as dictionary:
        wordPatterns = getWordPatternsFromDictionary(line.strip() for line in dictionary)

    dotChar = find_dot(cleanedEncrypted.split(spaceChar))
    solvedChars[dotChar] = '.'


    return inputText.replace(dotChar,'.').replace(spaceChar,' ')

def crack(inputText):
    solvedChars = {}


    # get all caps text with only chars that are in the given set of letters
    cleanedEncrypted = ''.join(c for c in inputText.upper() if c in LETTERS_DICT)

    letterFrequencies = getLetterFrequencies(cleanedEncrypted)

    # space is the most common char by far, so go ahead and solve it
    spaceChar = LETTERS[max_index(letterFrequencies)]
    solvedChars[spaceChar] = ' '

    # get all caps text with only chars that are in the given set of letters
    cleanedEncrypted = ''.join(spaceCharForWhiteSpace(inputText.upper(), spaceChar))
    wordPatterns = {}
    with open(DICTIONARY_FILENAME, 'r') as dictionary:
        wordPatterns = getWordPatternsFromDictionary(line.strip() for line in dictionary)

    dotChar = find_dot(cleanedEncrypted.split(spaceChar))
    solvedChars[dotChar] = '.'

    mappingCountsFromEachEncryptedChar = {char: {charInner: 0 for charInner in LETTERS} for char in LETTERS}
    mappingCountsToEachDecryptedChar = {char: {charInner: 0 for charInner in LETTERS} for char in LETTERS}
    for word in (wordInner.strip(dotChar) for wordInner in cleanedEncrypted.split(spaceChar)):
        processWord2(word, mappingCountsFromEachEncryptedChar, mappingCountsToEachDecryptedChar, wordPatterns, solvedChars)
        if len(solvedChars) == len(LETTERS):
            break
    for char in LETTERS:
        # We have already decrypted all spaces and dots
        if char != spaceChar and char != dotChar and char not in solvedChars:
            maxCount = 0
            bestChar = '_'
            for char2 in mappingCountsToEachDecryptedChar[char]:
                if mappingCountsToEachDecryptedChar[char][char2] > maxCount:
                    bestChar = char2
                    maxCount = mappingCountsToEachDecryptedChar[char][char2]
            solvedChars[char] = bestChar
    key = ''
    for char in LETTERS:
        key += solvedChars[char]
    key = flipKey(key)
    hackedText = ''.join(decryptChar(char, solvedChars) for char in inputText)


    return hackedText

def main():
    """
    The main function.
    """

    # retrieve command line arguments
    name_of_file_to_crack = argv[1]
    decrypted_file_to_write = argv[2]


    with open(name_of_file_to_crack, 'r') as encrypted, open(decrypted_file_to_write, 'w') as output:
        inputText = encrypted.read()

        outputText = crack(inputText)

        output.write(outputText)






if __name__=='__main__':
    main()
