#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import time

encrypted_books = [ 'Hacker_Crackdown.txt', 'Hackers_Heroes_of_the_Computer_Revolution.txt',
                    'Little_Brother.txt', 'Manual_for_the_Solution_of_Military_Ciphers.txt',
                    'The_Book_of_War.txt' ]

timer = []       # array to store time results

overall_start = time.time()            # start timer

try:
    for book in encrypted_books:

        print('Trying: ' + book)

        in_path = 'encrypted_books/' + book

        out_path = './' + book

        script = './betterSubCrack.py' + ' ' + in_path + ' ' + out_path

        start = time.time()

        # launching students python script
        os.system(script)

        end = time.time()

        total_time = (end - start)

        timer.append(round(total_time, 4))

except Exception as e:

    print("OOPS **** Something went wrong:", e)
    time.append(("OOPS **** Something went wrong:", e))

overall_end = time.time()
overall_time = overall_end - overall_start
timer.append(round(total_time, 4))


print(timer)
