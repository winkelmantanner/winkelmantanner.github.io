# Assignment 0

1. Thoroughly read the syllabus sections on "Programming assignments" and "Grading", including the links referenced within. 
These sections give good tips, tricks, hints, and instructions for programming assignments, including how to submit via Git.

2. Make sure you have ~15 Gb of free hard drive space, and >=4Gb of RAM

3. If you do not have a Mac, open your BIOS (Mac virtualization is usually enabled by default).
	
    a. F2, F8, or other function keys, and/or "Advanced Startup" from within Windows may help. Use your favorite search engine to find out how for your particular laptop.
	
    b. Once you have figured out how to enter your BIOS, then enable any features that sound like: virtualization, vt-x, vt-d, AMD-v, AMD-vi, NPT, RVI, etc.

4. Download VirtualBox: https://www.virtualbox.org/wiki/Downloads

5. Install VirtualBox 
	
    a. Launch and click through all, accepting the defaults (Mac and Windows)
	
    b. VirtualBox kernel modules require a restart, even in *nix, so restart your computer

6. Download Kali Linux: https://www.kali.org/downloads/ (The Xfce 64 Bit download is problabl your best bet), and install it within VirtualBox. For a general guide, read: http://web.mst.edu/~taylorpat/Courses_files/DataStructuresLab/Content/VirtualMachines.html

6. From within the virtual machine, open a terminal and clone this repository using the command line.
The resulting folder is your repository.

5. From within the virtual machine, read and perform the commands in the following guide on how to manage basic Linux/Unix command line work: http://linuxcommand.org/lc3_learning_the_shell.php .
Copy the ~/.bash_history file (which shows your command history from the tutorial) into your repository.
Add and commit your changes.

6. From within the virtual machine, push all the results. Verify you can see them on git-classes.

